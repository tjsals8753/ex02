package com.jslhrd.board;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
