package com.jslhrd.board.Mapper;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.annotations.Mapper;
import com.jslhrd.board.domain.BoardDTO;

@Mapper
public interface BoardMapper {
	//전체 글 수
	public int BoardCount();
	
	//전체 글
	public List<BoardDTO> BoardList();
	
	//특정 글 검색(type, key)
	public List<BoardDTO> BoardListSearch(BoardDTO dto);	
	
	//글 조회수 증가
	public void BoardHits(int idx);
	
	//특정글 검색(view, modify)
	public BoardDTO BoardView(int idx);
	
	//글 등록
	public int BoardWrite(BoardDTO dto);
	
	//수정
	public int BoardModify(BoardDTO dto);
	
	//삭제 
	public int BoardDelete(BoardDTO dto);
	
}
