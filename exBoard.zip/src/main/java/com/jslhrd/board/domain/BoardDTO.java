package com.jslhrd.board.domain;

import lombok.Data;

@Data
public class BoardDTO {
	private int idx;
	private String name;
	private String email;
	private String pass;
	private String subject;
	private String contents;
	private String regdate;
	private String type;
	private String key;
	private int readcnt;
}
