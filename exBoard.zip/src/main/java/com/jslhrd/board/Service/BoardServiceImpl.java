package com.jslhrd.board.Service;

import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jslhrd.board.Mapper.BoardMapper;
import com.jslhrd.board.domain.BoardDTO;

@Service
public class BoardServiceImpl implements BoardService {
	private static final Logger log = LoggerFactory.getLogger(BoardService.class);
	
	@Autowired
	private BoardMapper mapper;
	
	@Override
	public int BoardCount() {
		return mapper.BoardCount();
	}

	@Override
	public List<BoardDTO> BoardList() {
		return mapper.BoardList();
	}
	
	@Override
	public void BoardHits(int idx, HttpServletRequest request, HttpServletResponse response) { 
			//쿠키설정
			boolean bool=false;
			Cookie info = null;
			Cookie[] cookies = request.getCookies();
			for(int i=0; i<cookies.length; i++) {
				info =cookies[i];
				if(info.getName().equals("boardCookie"+idx)) {
					bool = true;
					break;
				}
			}
			String str= "" + System.currentTimeMillis();
			if(!bool) { //쿠키가 존재하지 않으면 쿠키 생성하면서 readcnt 증가
				info = new Cookie("boardCookie"+idx, str);
				info.setMaxAge(60*5); //쿠키 5분유지
				response.addCookie(info);
				mapper.BoardHits(idx);		
			}
	}
	
	@Override
	public BoardDTO BoardView(int idx) {
		return mapper.BoardView(idx);
	}
	
	@Override
	public List<BoardDTO> BoardListSearch(BoardDTO dto) {
		log.info("Service search....." + dto.getType() + " / " + dto.getKey());
		return mapper.BoardListSearch(dto);
	}
	
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
}
