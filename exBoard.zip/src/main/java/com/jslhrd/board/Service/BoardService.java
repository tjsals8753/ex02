package com.jslhrd.board.Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jslhrd.board.domain.BoardDTO;

public interface BoardService {
	//전체 글 수
	public int BoardCount();
		
	//전체 글
	public List<BoardDTO> BoardList();
		
	//특정 글 검색(type, key)
	public List<BoardDTO> BoardListSearch(BoardDTO dto);
	
	//글 조회수 증가
	public void BoardHits(int idx, HttpServletRequest request, HttpServletResponse response);
		
	//특정글 검색(view, modify)
	public BoardDTO BoardView(int idx);
		
	//글 등록
		
	//수정
		
	//삭제 
}
